#import <Flutter/Flutter.h>

@interface NasStreamFlutterPlugin : NSObject<FlutterPlugin>
@end
