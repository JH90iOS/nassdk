#import <Flutter/Flutter.h>

@interface GallerySaverPlugin : NSObject<FlutterPlugin>
@end
