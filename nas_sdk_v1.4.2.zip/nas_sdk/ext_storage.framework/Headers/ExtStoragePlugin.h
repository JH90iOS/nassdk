#import <Flutter/Flutter.h>

@interface ExtStoragePlugin : NSObject<FlutterPlugin>
@end
