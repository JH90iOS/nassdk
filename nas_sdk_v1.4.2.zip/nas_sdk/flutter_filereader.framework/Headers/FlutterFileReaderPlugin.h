#import <Flutter/Flutter.h>

@interface FlutterFileReaderPlugin: NSObject<FlutterPlugin>
@end
